<?php

interface KontrakView{
	public function tampil();
}

?>